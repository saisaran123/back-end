package com.kunto.model;

public class user_details {
    private String goal;
    private int height;
    private int weight;
    private String level;
    private String activeLevel;
    private String gender;
    private String dateOfBirth;
    private String country;
    private String city;
    private String username;
    private int id ;

    // Getters and Setters
    public String getGoal() { return goal; }
    public void setGoal(String goal) { this.goal = goal; }
    
    public int getHeight() { return height; }
    public void setHeight(int i) { this.height = i; }
    
    public int getWeight() { return weight; }
    public void setWeight(int i) { this.weight = i; }
    
    public String getLevel() { return level; }
    public void setLevel(String level) { this.level = level; }
    
    public String getActiveLevel() { return activeLevel; }
    public void setActiveLevel(String activeLevel) { this.activeLevel = activeLevel; }
    
    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }
    
    public String getDateOfBirth() { return dateOfBirth; }
    public void setDateOfBirth(String dateOfBirth) { this.dateOfBirth = dateOfBirth; }
    
    public String getCountry() { return country; }
    public void setCountry(String country) { this.country = country; }
    
    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }
    
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    
	public int getId() {return id;}
	public void setId(int id) {this.id = id;}
}
