//package com.kunto.model;
//public class GroupMessage {
//    private int id;
//    private int groupId;
//    private int senderId;
//    private String message;
//    private Timestamp timestamp;
//
//    public GroupMessage() {}
//
//    public GroupMessage(int id, int groupId, int senderId, String message, Timestamp timestamp) {
//        this.id = id;
//        this.groupId = groupId;
//        this.senderId = senderId;
//        this.message = message;
//        this.timestamp = timestamp;
//    }
//
//    public int getId() { return id; }
//    public void setId(int id) { this.id = id; }
//    public int getGroupId() { return groupId; }
//    public void setGroupId(int groupId) { this.groupId = groupId; }
//    public int getSenderId() { return senderId; }
//    public void setSenderId(int senderId) { this.senderId = senderId; }
//    public String getMessage() { return message; }
//    public void setMessage(String message) { this.message = message; }
//    public Timestamp getTimestamp() { return timestamp; }
//    public void setTimestamp(Timestamp timestamp) { this.timestamp = timestamp; }
//}
