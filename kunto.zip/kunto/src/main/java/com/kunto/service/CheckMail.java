package com.kunto.service;

import java.util.jar.Attributes.Name;

import com.kunto.util.Mail;

public class CheckMail{
	
	public void name() {
	}
	
}